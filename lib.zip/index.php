<?php

require 'lib/autoload.php';


use HelloWorld\HelloWorld;

$hello = new HelloWorld();
$hello->HelloWorld();

use hehe\hello;

$hhh = new hello();
