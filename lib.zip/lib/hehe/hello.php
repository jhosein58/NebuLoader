<?php

namespace hehe;

class hello
{
    public function __construct()
    {
        echo 'hello world';
    }
}