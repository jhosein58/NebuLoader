<?php

require __DIR__ . '/StaticLoader.php';
require __DIR__ . '/Config.php';
require __DIR__ . '/Application.php';