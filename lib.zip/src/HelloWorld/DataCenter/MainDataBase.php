<?php

namespace HelloWorld\DataCenter;
class MainDataBase
{
    public array $data = [
        '48656c6c6f20576f726c642021',
    ];
}